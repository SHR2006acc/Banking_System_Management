"""Dataclasses du domaine.

NOTE : ce fichier appartient à la Personne 2 (Domaine & Règles métier).
Version minimale fournie par la Personne 1 pour que les DAO et leurs tests
fonctionnent. La Personne 2 peut l'enrichir/remplacer à condition de garder
les mêmes noms de champs (ils correspondent aux colonnes du schéma SQL).
"""
from dataclasses import dataclass
from typing import Optional


@dataclass
class Client:
    nom: str
    prenom: str
    cin: str
    telephone: Optional[str] = None
    email: Optional[str] = None
    statut: str = "ACTIF"
    id: Optional[int] = None
    date_creation: Optional[str] = None


@dataclass
class Compte:
    id_client: int
    numero: str
    type: str = "COURANT"
    solde: float = 0.0
    statut: str = "ACTIF"
    id: Optional[int] = None
    date_ouverture: Optional[str] = None


@dataclass
class Operation:
    id_compte: int
    type: str
    montant: float
    id_contrepartie: Optional[int] = None
    id_virement: Optional[str] = None
    commentaire: Optional[str] = None
    id: Optional[int] = None
    date_op: Optional[str] = None
