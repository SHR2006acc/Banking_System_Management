# Système bancaire - Python avancé

Projet en 3 rôles : **Données & Persistance** (P1), **Domaine & Règles métier** (P2), **Interface & UX** (P3).

## Structure

```
schema.sql              # P1 - DDL + contraintes
db_manager.py           # P1 - connexion, init_schema, transactions
dao/                    # P1 - ClientDAO, CompteDAO, OperationDAO
seed.py                 # P1 - données de démo
tests/test_dao.py       # P1 - tests unitaires des DAO
models/models.py        # P2 - dataclasses (version minimale fournie par P1)
services/bank_service.py   # P2 (à faire)
exceptions.py              # P2 (à faire)
ui/ , main.py              # P3 (à faire)
docs/rapport_P1.md      # P1 - section du rapport
```

## Démarrer

```bash
python seed.py                                   # crée banque.db avec les données de démo
python -m unittest discover -s tests -t . -v     # lance les tests (aucune dépendance externe)
```

## Contrat DAO (à lire par P2 et P3)

Toutes les méthodes DAO acceptent un paramètre optionnel `conn`.

- **Sans `conn`** : le DAO gère sa propre transaction (COMMIT/ROLLBACK automatiques).
- **Avec `conn`** : le DAO participe à la transaction de l'appelant.

**P2 - virement atomique** (2 jambes + 2 soldes en UNE transaction) :

```python
with db.transaction() as conn:
    comptes.update_solde(id_a, solde_a - montant, conn=conn)
    comptes.update_solde(id_b, solde_b + montant, conn=conn)
    ops.create(Operation(id_a, "VIREMENT", montant, id_b, vid, "Débit"), conn=conn)
    ops.create(Operation(id_b, "VIREMENT", montant, id_a, vid, "Crédit"), conn=conn)
# exception dans le bloc => ROLLBACK de tout
```

Signatures :

| DAO | Méthodes |
|---|---|
| `ClientDAO` | `create(Client)->int`, `read_all()`, `read_by_id(int)`, `read_by_cin(str)`, `update(Client)->bool`, `delete(int)->bool` |
| `CompteDAO` | `create(Compte)->int`, `read_all()`, `read_by_id(int)`, `by_client(int)`, `update_solde(int, float)->bool`, `update(Compte)->bool`, `delete(int)->bool` |
| `OperationDAO` | `create(Operation)->int`, `history(int)`, `legs_of_virement(str)`, `count_all()` |

Les violations de contraintes (CIN/numéro dupliqué, solde négatif, FK inexistante...) lèvent `sqlite3.IntegrityError` : le service (P2) doit les traduire en exceptions métier.

Un `delete` de client qui possède des comptes est refusé par la clé étrangère (`IntegrityError`) ; la règle métier "suppression bloquée" reste à vérifier côté service pour afficher un message clair.
