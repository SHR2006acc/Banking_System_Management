"""CRUD de la table compte. Requêtes paramétrées uniquement."""
from typing import List, Optional

from db_manager import DatabaseManager
from models.models import Compte


def _row_to_compte(row) -> Compte:
    return Compte(
        id=row["id_compte"],
        id_client=row["id_client"],
        numero=row["numero"],
        type=row["type"],
        solde=row["solde"],
        statut=row["statut"],
        date_ouverture=row["date_ouverture"],
    )


class CompteDAO:
    def __init__(self, db: DatabaseManager):
        self.db = db

    def create(self, compte: Compte, conn=None) -> int:
        with self.db.use(conn) as c:
            cur = c.execute(
                "INSERT INTO compte (id_client, numero, type, solde, statut) "
                "VALUES (?, ?, ?, ?, ?)",
                (compte.id_client, compte.numero, compte.type,
                 compte.solde, compte.statut),
            )
            return cur.lastrowid

    def read_all(self, conn=None) -> List[Compte]:
        with self.db.use(conn) as c:
            rows = c.execute("SELECT * FROM compte ORDER BY id_compte").fetchall()
            return [_row_to_compte(r) for r in rows]

    def read_by_id(self, id_compte: int, conn=None) -> Optional[Compte]:
        with self.db.use(conn) as c:
            row = c.execute(
                "SELECT * FROM compte WHERE id_compte = ?", (id_compte,)
            ).fetchone()
            return _row_to_compte(row) if row else None

    def by_client(self, id_client: int, conn=None) -> List[Compte]:
        with self.db.use(conn) as c:
            rows = c.execute(
                "SELECT * FROM compte WHERE id_client = ? ORDER BY id_compte",
                (id_client,),
            ).fetchall()
            return [_row_to_compte(r) for r in rows]

    def update_solde(self, id_compte: int, nouveau_solde: float, conn=None) -> bool:
        """Remplace le solde. La contrainte CHECK (solde >= 0) refuse un solde négatif
        (sqlite3.IntegrityError), même si le service oublie de vérifier."""
        with self.db.use(conn) as c:
            cur = c.execute(
                "UPDATE compte SET solde = ? WHERE id_compte = ?",
                (nouveau_solde, id_compte),
            )
            return cur.rowcount > 0

    def update(self, compte: Compte, conn=None) -> bool:
        with self.db.use(conn) as c:
            cur = c.execute(
                "UPDATE compte SET id_client = ?, numero = ?, type = ?, "
                "solde = ?, statut = ? WHERE id_compte = ?",
                (compte.id_client, compte.numero, compte.type,
                 compte.solde, compte.statut, compte.id),
            )
            return cur.rowcount > 0

    def delete(self, id_compte: int, conn=None) -> bool:
        with self.db.use(conn) as c:
            cur = c.execute("DELETE FROM compte WHERE id_compte = ?", (id_compte,))
            return cur.rowcount > 0
