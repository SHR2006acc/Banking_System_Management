"""Table operation : journal append-only (création + lecture, jamais de modification).
Requêtes paramétrées uniquement."""
from typing import List

from db_manager import DatabaseManager
from models.models import Operation


def _row_to_operation(row) -> Operation:
    return Operation(
        id=row["id_operation"],
        id_compte=row["id_compte"],
        id_contrepartie=row["id_contrepartie"],
        type=row["type"],
        montant=row["montant"],
        id_virement=row["id_virement"],
        date_op=row["date_op"],
        commentaire=row["commentaire"],
    )


class OperationDAO:
    def __init__(self, db: DatabaseManager):
        self.db = db

    def create(self, op: Operation, conn=None) -> int:
        with self.db.use(conn) as c:
            cur = c.execute(
                "INSERT INTO operation (id_compte, id_contrepartie, type, montant, "
                "id_virement, commentaire) VALUES (?, ?, ?, ?, ?, ?)",
                (op.id_compte, op.id_contrepartie, op.type, op.montant,
                 op.id_virement, op.commentaire),
            )
            return cur.lastrowid

    def history(self, id_compte: int, conn=None) -> List[Operation]:
        """Historique d'un compte, du plus récent au plus ancien."""
        with self.db.use(conn) as c:
            rows = c.execute(
                "SELECT * FROM operation WHERE id_compte = ? "
                "ORDER BY date_op DESC, id_operation DESC",
                (id_compte,),
            ).fetchall()
            return [_row_to_operation(r) for r in rows]

    def legs_of_virement(self, id_virement: str, conn=None) -> List[Operation]:
        """Les DEUX jambes (débit + crédit) d'un même virement."""
        with self.db.use(conn) as c:
            rows = c.execute(
                "SELECT * FROM operation WHERE id_virement = ? ORDER BY id_operation",
                (id_virement,),
            ).fetchall()
            return [_row_to_operation(r) for r in rows]

    def count_all(self, conn=None) -> int:
        """Pour le tableau de bord (volume d'opérations)."""
        with self.db.use(conn) as c:
            return c.execute("SELECT COUNT(*) FROM operation").fetchone()[0]
