"""CRUD de la table client. Requêtes paramétrées uniquement (jamais de f-string SQL)."""
from typing import List, Optional

from db_manager import DatabaseManager
from models.models import Client


def _row_to_client(row) -> Client:
    return Client(
        id=row["id_client"],
        nom=row["nom"],
        prenom=row["prenom"],
        cin=row["cin"],
        telephone=row["telephone"],
        email=row["email"],
        statut=row["statut"],
        date_creation=row["date_creation"],
    )


class ClientDAO:
    def __init__(self, db: DatabaseManager):
        self.db = db

    def create(self, client: Client, conn=None) -> int:
        with self.db.use(conn) as c:
            cur = c.execute(
                "INSERT INTO client (nom, prenom, cin, telephone, email, statut) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (client.nom, client.prenom, client.cin,
                 client.telephone, client.email, client.statut),
            )
            return cur.lastrowid

    def read_all(self, conn=None) -> List[Client]:
        with self.db.use(conn) as c:
            rows = c.execute("SELECT * FROM client ORDER BY id_client").fetchall()
            return [_row_to_client(r) for r in rows]

    def read_by_id(self, id_client: int, conn=None) -> Optional[Client]:
        with self.db.use(conn) as c:
            row = c.execute(
                "SELECT * FROM client WHERE id_client = ?", (id_client,)
            ).fetchone()
            return _row_to_client(row) if row else None

    def read_by_cin(self, cin: str, conn=None) -> Optional[Client]:
        with self.db.use(conn) as c:
            row = c.execute("SELECT * FROM client WHERE cin = ?", (cin,)).fetchone()
            return _row_to_client(row) if row else None

    def update(self, client: Client, conn=None) -> bool:
        with self.db.use(conn) as c:
            cur = c.execute(
                "UPDATE client SET nom = ?, prenom = ?, cin = ?, telephone = ?, "
                "email = ?, statut = ? WHERE id_client = ?",
                (client.nom, client.prenom, client.cin, client.telephone,
                 client.email, client.statut, client.id),
            )
            return cur.rowcount > 0

    def delete(self, id_client: int, conn=None) -> bool:
        with self.db.use(conn) as c:
            cur = c.execute("DELETE FROM client WHERE id_client = ?", (id_client,))
            return cur.rowcount > 0
