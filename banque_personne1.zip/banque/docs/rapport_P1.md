# Rôle 1 : Données & Persistance

## 1. Schéma relationnel

Le système repose sur trois tables SQLite : `client`, `compte` et `operation`.

```
client (1) ───< compte (1) ───< operation
                    ▲                │
                    └── id_contrepartie (autre compte d'un virement)
```

- Un **client** possède 0..n **comptes** (`compte.id_client` → `client.id_client`).
- Un **compte** possède 0..n **opérations** (`operation.id_compte` → `compte.id_compte`).
- Une opération de type virement référence aussi le compte adverse via `id_contrepartie`.

## 2. Justification des contraintes

| Contrainte | Où | Pourquoi |
|---|---|---|
| `PRIMARY KEY AUTOINCREMENT` | les 3 tables | Identifiant technique stable, jamais réutilisé après suppression : indispensable pour un historique bancaire. |
| `cin UNIQUE NOT NULL` | client | Un CIN identifie une seule personne ; empêche les doublons de clients. |
| `numero UNIQUE NOT NULL` | compte | Le numéro de compte est l'identifiant métier visible ; deux comptes ne peuvent pas le partager. |
| `statut CHECK (IN 'ACTIF','SUSPENDU')` | client | Restreint le champ à un ensemble fermé de valeurs (énumération), sans table annexe. |
| `type CHECK (IN 'COURANT','EPARGNE')` | compte | Même principe ; une valeur inconnue est rejetée par la base elle-même. |
| `statut CHECK (IN 'ACTIF','CLOTURE')` | compte | Une clôture est un changement d'état, pas une suppression : l'historique des opérations reste valide. |
| **`solde CHECK (solde >= 0)`** | compte | Règle métier critique appliquée **au niveau de la base** : même si le service oublie de vérifier, un solde négatif est impossible (dernier filet de sécurité). |
| `type CHECK (IN 'DEPOT','RETRAIT','VIREMENT')` | operation | Ensemble fermé de types d'opérations. |
| **`montant CHECK (montant > 0)`** | operation | Interdit les montants nuls ou négatifs, qui permettraient de contourner un retrait par un « dépôt négatif ». Le sens de l'opération est porté par `type`. |
| `REFERENCES` (clés étrangères) | compte, operation | Intégrité référentielle : pas de compte sans client, pas d'opération sans compte. Active grâce à `PRAGMA foreign_keys = ON` (désactivé par défaut dans SQLite). |
| `id_virement TEXT` (UUID) | operation | Regroupe les **deux jambes** (débit et crédit) d'un même virement : retrouver et auditer un virement complet, vérifier la double écriture. |
| `INDEX idx_op_compte` | operation | Accélère l'historique d'un compte (`WHERE id_compte = ?`), requête la plus fréquente de l'application. |
| `DEFAULT (datetime('now','localtime'))` | dates | Horodatage rempli par la base : cohérent et non falsifiable depuis l'interface. |
| `NOT NULL` | colonnes obligatoires | Empêche les enregistrements incomplets. |

**Choix de conception.** La table `operation` est un **journal en ajout seul** (append-only) : le DAO n'expose ni `update` ni `delete`. On ne corrige pas une opération, on en ajoute une nouvelle, comme dans un vrai système comptable.

**Limite assumée.** Le type `REAL` (flottant) est utilisé pour les montants, conformément au schéma du sujet. En production, on utiliserait des entiers en centimes ou `Decimal` pour éviter les erreurs d'arrondi.

## 3. Couche d'accès aux données (DAO)

- **Requêtes paramétrées uniquement** (`?`) : aucune concaténation de chaînes SQL, donc protection contre l'injection SQL. Un test (`test_sql_injection_is_harmless`) le vérifie avec une valeur du type `x'); DROP TABLE client;--`.
- **Gestion des transactions** : `DatabaseManager.transaction()` encapsule `with conn:` (COMMIT si tout réussit, ROLLBACK sur exception). Chaque méthode DAO accepte un paramètre `conn` optionnel : le service peut ainsi englober plusieurs appels DAO dans **une seule transaction**, ce qui rend le virement atomique.
- **Tests** : 24 tests unitaires (CRUD, chaque contrainte, historique, jambes d'un virement, seed idempotent). Deux tests de transaction montrent le COMMIT global en cas de succès et le **ROLLBACK complet** (soldes inchangés, aucune jambe enregistrée) en cas d'échec au milieu d'un virement.

## 4. Données de démonstration

`seed.py` crée 3 clients, 4 comptes et un jeu d'opérations incluant un virement à deux jambes. Il est idempotent (sans effet si la base contient déjà des clients) et s'exécute dans une seule transaction.
