"""Données de démonstration. Idempotent : ne fait rien si la base contient déjà des clients."""
import uuid

from dao import ClientDAO, CompteDAO, OperationDAO
from models.models import Client, Compte, Operation


def seed(db) -> None:
    clients = ClientDAO(db)
    comptes = CompteDAO(db)
    ops = OperationDAO(db)

    if clients.read_all():
        return

    with db.transaction() as conn:
        ids = []
        for nom, prenom, cin, tel, email in [
            ("Alaoui", "Youssef", "BK123456", "0612345678", "y.alaoui@example.com"),
            ("Benani", "Salma", "BE654321", "0623456789", "s.benani@example.com"),
            ("Chraibi", "Omar", "AB987654", "0634567890", "o.chraibi@example.com"),
        ]:
            ids.append(clients.create(Client(nom, prenom, cin, tel, email), conn=conn))

        c1 = comptes.create(Compte(ids[0], "MA0001", "COURANT", 5000.0), conn=conn)
        c2 = comptes.create(Compte(ids[0], "MA0002", "EPARGNE", 12000.0), conn=conn)
        c3 = comptes.create(Compte(ids[1], "MA0003", "COURANT", 800.0), conn=conn)
        comptes.create(Compte(ids[2], "MA0004", "COURANT", 0.0), conn=conn)

        ops.create(Operation(c1, "DEPOT", 5000.0, commentaire="Dépôt initial"), conn=conn)
        ops.create(Operation(c2, "DEPOT", 12000.0, commentaire="Dépôt initial"), conn=conn)
        ops.create(Operation(c3, "DEPOT", 1000.0, commentaire="Dépôt initial"), conn=conn)
        ops.create(Operation(c3, "RETRAIT", 200.0, commentaire="Distributeur"), conn=conn)

        # un virement c1 -> c3 de 300 (2 jambes, même id_virement). Soldes ajustés.
        vid = str(uuid.uuid4())
        ops.create(Operation(c1, "VIREMENT", 300.0, id_contrepartie=c3,
                             id_virement=vid, commentaire="Débit"), conn=conn)
        ops.create(Operation(c3, "VIREMENT", 300.0, id_contrepartie=c1,
                             id_virement=vid, commentaire="Crédit"), conn=conn)
        comptes.update_solde(c1, 4700.0, conn=conn)
        comptes.update_solde(c3, 1100.0, conn=conn)


if __name__ == "__main__":
    from db_manager import DatabaseManager

    manager = DatabaseManager("banque.db")
    manager.init_schema()
    seed(manager)
    print("Base banque.db initialisée avec les données de démo.")
