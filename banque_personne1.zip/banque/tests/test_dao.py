import sqlite3
import unittest
import uuid

from dao import ClientDAO, CompteDAO, OperationDAO
from db_manager import DatabaseManager
from models.models import Client, Compte, Operation
from seed import seed


class BaseDAOTest(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseManager(":memory:")
        self.db.init_schema()
        self.clients = ClientDAO(self.db)
        self.comptes = CompteDAO(self.db)
        self.ops = OperationDAO(self.db)

    def _client(self, cin="X1"):
        return self.clients.create(Client("Nom", "Prenom", cin))

    def _compte(self, id_client, numero="N1", solde=100.0):
        return self.comptes.create(Compte(id_client, numero, solde=solde))


class TestClientDAO(BaseDAOTest):
    def test_create_and_read(self):
        cid = self._client()
        c = self.clients.read_by_id(cid)
        self.assertEqual(c.nom, "Nom")
        self.assertEqual(c.statut, "ACTIF")
        self.assertIsNotNone(c.date_creation)
        self.assertEqual(len(self.clients.read_all()), 1)

    def test_read_missing_returns_none(self):
        self.assertIsNone(self.clients.read_by_id(999))

    def test_cin_unique(self):
        self._client("DUP")
        with self.assertRaises(sqlite3.IntegrityError):
            self._client("DUP")

    def test_statut_check(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.clients.create(Client("A", "B", "C1", statut="INCONNU"))

    def test_update(self):
        cid = self._client()
        c = self.clients.read_by_id(cid)
        c.nom = "Modifie"
        self.assertTrue(self.clients.update(c))
        self.assertEqual(self.clients.read_by_id(cid).nom, "Modifie")

    def test_delete(self):
        cid = self._client()
        self.assertTrue(self.clients.delete(cid))
        self.assertFalse(self.clients.delete(cid))

    def test_delete_blocked_by_foreign_key(self):
        cid = self._client()
        self._compte(cid)
        with self.assertRaises(sqlite3.IntegrityError):
            self.clients.delete(cid)

    def test_sql_injection_is_harmless(self):
        cid = self.clients.create(Client("x'); DROP TABLE client;--", "p", "INJ"))
        self.assertEqual(self.clients.read_by_id(cid).nom, "x'); DROP TABLE client;--")
        self.assertEqual(len(self.clients.read_all()), 1)


class TestCompteDAO(BaseDAOTest):
    def test_create_and_by_client(self):
        cid = self._client()
        self._compte(cid, "A")
        self._compte(cid, "B")
        self.assertEqual(len(self.comptes.by_client(cid)), 2)
        self.assertEqual(len(self.comptes.read_all()), 2)

    def test_numero_unique(self):
        cid = self._client()
        self._compte(cid, "A")
        with self.assertRaises(sqlite3.IntegrityError):
            self._compte(cid, "A")

    def test_unknown_client_rejected(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.comptes.create(Compte(999, "Z"))

    def test_negative_solde_rejected(self):
        cid = self._client()
        id_compte = self._compte(cid, solde=50.0)
        with self.assertRaises(sqlite3.IntegrityError):
            self.comptes.update_solde(id_compte, -1.0)
        self.assertEqual(self.comptes.read_by_id(id_compte).solde, 50.0)

    def test_update_solde(self):
        cid = self._client()
        id_compte = self._compte(cid)
        self.assertTrue(self.comptes.update_solde(id_compte, 250.0))
        self.assertEqual(self.comptes.read_by_id(id_compte).solde, 250.0)

    def test_update_and_close(self):
        cid = self._client()
        id_compte = self._compte(cid)
        c = self.comptes.read_by_id(id_compte)
        c.statut = "CLOTURE"
        self.assertTrue(self.comptes.update(c))
        self.assertEqual(self.comptes.read_by_id(id_compte).statut, "CLOTURE")

    def test_type_check(self):
        cid = self._client()
        with self.assertRaises(sqlite3.IntegrityError):
            self.comptes.create(Compte(cid, "T", type="AUTRE"))

    def test_delete(self):
        cid = self._client()
        id_compte = self._compte(cid)
        self.assertTrue(self.comptes.delete(id_compte))
        self.assertIsNone(self.comptes.read_by_id(id_compte))


class TestOperationDAO(BaseDAOTest):
    def test_create_and_history_order(self):
        cid = self._client()
        id_compte = self._compte(cid)
        self.ops.create(Operation(id_compte, "DEPOT", 10.0))
        self.ops.create(Operation(id_compte, "RETRAIT", 5.0))
        hist = self.ops.history(id_compte)
        self.assertEqual([o.type for o in hist], ["RETRAIT", "DEPOT"])  # plus récent d'abord

    def test_montant_must_be_positive(self):
        cid = self._client()
        id_compte = self._compte(cid)
        for montant in (0, -5):
            with self.assertRaises(sqlite3.IntegrityError):
                self.ops.create(Operation(id_compte, "DEPOT", montant))

    def test_type_check(self):
        cid = self._client()
        id_compte = self._compte(cid)
        with self.assertRaises(sqlite3.IntegrityError):
            self.ops.create(Operation(id_compte, "CADEAU", 10.0))

    def test_legs_of_virement(self):
        cid = self._client()
        a = self._compte(cid, "A")
        b = self._compte(cid, "B")
        vid = str(uuid.uuid4())
        self.ops.create(Operation(a, "VIREMENT", 20.0, id_contrepartie=b, id_virement=vid))
        self.ops.create(Operation(b, "VIREMENT", 20.0, id_contrepartie=a, id_virement=vid))
        self.ops.create(Operation(a, "DEPOT", 1.0))
        legs = self.ops.legs_of_virement(vid)
        self.assertEqual(len(legs), 2)
        self.assertEqual({leg.id_compte for leg in legs}, {a, b})

    def test_count_all(self):
        cid = self._client()
        id_compte = self._compte(cid)
        self.ops.create(Operation(id_compte, "DEPOT", 1.0))
        self.assertEqual(self.ops.count_all(), 1)


class TestTransactions(BaseDAOTest):
    """Le point critique pour la Personne 2 : atomicité d'un virement."""

    def test_commit_when_all_ok(self):
        cid = self._client()
        a = self._compte(cid, "A", 100.0)
        b = self._compte(cid, "B", 0.0)
        vid = str(uuid.uuid4())
        with self.db.transaction() as conn:
            self.comptes.update_solde(a, 70.0, conn=conn)
            self.comptes.update_solde(b, 30.0, conn=conn)
            self.ops.create(Operation(a, "VIREMENT", 30.0, b, vid), conn=conn)
            self.ops.create(Operation(b, "VIREMENT", 30.0, a, vid), conn=conn)
        self.assertEqual(self.comptes.read_by_id(a).solde, 70.0)
        self.assertEqual(self.comptes.read_by_id(b).solde, 30.0)
        self.assertEqual(len(self.ops.legs_of_virement(vid)), 2)

    def test_rollback_on_failure(self):
        cid = self._client()
        a = self._compte(cid, "A", 100.0)
        b = self._compte(cid, "B", 0.0)
        vid = str(uuid.uuid4())
        with self.assertRaises(sqlite3.IntegrityError):
            with self.db.transaction() as conn:
                self.comptes.update_solde(a, 70.0, conn=conn)
                self.ops.create(Operation(a, "VIREMENT", 30.0, b, vid), conn=conn)
                # échec volontaire : solde négatif -> CHECK violé
                self.comptes.update_solde(b, -999.0, conn=conn)
        # TOUT a été annulé : soldes inchangés, aucune jambe enregistrée
        self.assertEqual(self.comptes.read_by_id(a).solde, 100.0)
        self.assertEqual(self.comptes.read_by_id(b).solde, 0.0)
        self.assertEqual(self.ops.legs_of_virement(vid), [])


class TestSeed(BaseDAOTest):
    def test_seed_is_idempotent_and_consistent(self):
        seed(self.db)
        seed(self.db)  # 2e appel : ne duplique rien
        self.assertEqual(len(self.clients.read_all()), 3)
        self.assertEqual(len(self.comptes.read_all()), 4)
        legs = [o for o in self.ops.history(1) if o.type == "VIREMENT"]
        self.assertEqual(len(self.ops.legs_of_virement(legs[0].id_virement)), 2)


if __name__ == "__main__":
    unittest.main()
