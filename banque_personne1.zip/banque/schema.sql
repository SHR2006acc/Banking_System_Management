PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS client (
    id_client     INTEGER PRIMARY KEY AUTOINCREMENT,
    nom           TEXT NOT NULL,
    prenom        TEXT NOT NULL,
    cin           TEXT NOT NULL UNIQUE,
    telephone     TEXT,
    email         TEXT,
    statut        TEXT NOT NULL DEFAULT 'ACTIF' CHECK (statut IN ('ACTIF','SUSPENDU')),
    date_creation TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS compte (
    id_compte      INTEGER PRIMARY KEY AUTOINCREMENT,
    id_client      INTEGER NOT NULL REFERENCES client(id_client),
    numero         TEXT NOT NULL UNIQUE,
    type           TEXT NOT NULL DEFAULT 'COURANT' CHECK (type IN ('COURANT','EPARGNE')),
    solde          REAL NOT NULL DEFAULT 0 CHECK (solde >= 0),
    statut         TEXT NOT NULL DEFAULT 'ACTIF' CHECK (statut IN ('ACTIF','CLOTURE')),
    date_ouverture TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS operation (
    id_operation    INTEGER PRIMARY KEY AUTOINCREMENT,
    id_compte       INTEGER NOT NULL REFERENCES compte(id_compte),
    id_contrepartie INTEGER REFERENCES compte(id_compte), -- other account for transfers
    type            TEXT NOT NULL CHECK (type IN ('DEPOT','RETRAIT','VIREMENT')),
    montant         REAL NOT NULL CHECK (montant > 0),
    id_virement     TEXT, -- uuid grouping the TWO legs of one transfer
    date_op         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    commentaire     TEXT
);

CREATE INDEX IF NOT EXISTS idx_op_compte ON operation(id_compte);
