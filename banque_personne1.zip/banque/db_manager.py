"""Gestionnaire de connexion SQLite (Personne 1 - Données & Persistance).

Principe : chaque méthode DAO accepte un paramètre optionnel ``conn``.
- Sans ``conn`` : le DAO ouvre sa propre connexion et valide/annule seul (autocommit par appel).
- Avec ``conn`` : le DAO participe à la transaction de l'appelant. C'est ce qui permet
  à BankService.virement() (Personne 2) d'englober plusieurs appels DAO dans UNE
  seule transaction avec rollback en cas d'échec :

    with db.transaction() as conn:
        comptes.update_solde(a, nouveau_a, conn=conn)
        comptes.update_solde(b, nouveau_b, conn=conn)
        ops.create(op_debit, conn=conn)
        ops.create(op_credit, conn=conn)
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

SCHEMA_PATH = Path(__file__).with_name("schema.sql")


class DatabaseManager:
    def __init__(self, db_path: str = "banque.db"):
        self.db_path = db_path
        self._keepalive = None
        if db_path == ":memory:":
            # une base en mémoire disparaît à la fermeture de la connexion :
            # on garde une connexion unique partagée.
            self._keepalive = self._new_connection()

    def _new_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def connect(self) -> sqlite3.Connection:
        return self._keepalive if self._keepalive is not None else self._new_connection()

    def _release(self, conn: sqlite3.Connection) -> None:
        if conn is not self._keepalive:
            conn.close()

    @contextmanager
    def transaction(self):
        """Ouvre une transaction : COMMIT si tout va bien, ROLLBACK si exception."""
        conn = self.connect()
        try:
            with conn:  # commit / rollback automatiques
                yield conn
        finally:
            self._release(conn)

    @contextmanager
    def use(self, conn=None):
        """Utilisé par les DAO : réutilise ``conn`` si fourni, sinon ouvre une transaction."""
        if conn is not None:
            yield conn
        else:
            with self.transaction() as c:
                yield c

    def init_schema(self) -> None:
        script = SCHEMA_PATH.read_text(encoding="utf-8")
        conn = self.connect()
        try:
            conn.executescript(script)
            conn.commit()
        finally:
            self._release(conn)

    def seed_demo_data(self) -> None:
        from seed import seed
        seed(self)
